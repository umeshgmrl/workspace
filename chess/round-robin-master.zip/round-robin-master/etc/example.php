<?php

include_once (bool) random_int(0, 1) ? 'example-oo.php' : 'example-procedural.php';
